package com.example.makeup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


public class menuone extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menuone);

        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollView.setLayoutParams(layoutParams);

        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setLayoutParams(linearParams);

        scrollView.addView(linearLayout);

        TextView titel = new  TextView(this);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params1.setMargins(0, 30, 0, 0);
        params1.gravity = Gravity.CENTER;
        titel.setLayoutParams(params1);
        titel.setTextSize(30);
        titel.setGravity(50);
        Typeface typefacetitel = getResources().getFont(R.font.kitvxvf);
        titel.setTypeface(typefacetitel);
        titel.setText("                แต่งหน้า ลุคเกาหลี");
//        titel.setText("1.คูชั่น : ลงคูชั่นลงทั่วบริเวณใบหน้า");
//        titel.setText("2.คิ้ว : เขียนคิ้วสไตล์ของท่าน ให้ดูสาวเกาหลี");
//        text.setText("3.ตา : เน้นโทนธรรมชาติแบบสีน้ำตาล");
//        text.setText("4.อายไลน์เนอร์ : เขียนอายไลน์เนอร์ ให้หางตกลงมา");
//        text.setText("5.ปาก : สาวเกาหลีนิยมทาลิปสติกแบบเบลอ นัวๆตรงขอบปาก ");
//        text.setText("6.แก้ม : เน้นสีที่เป็นธรรมชาติ จะได้ไม่ดูโดดจนเกินไป");

        linearLayout.addView(titel);

        TextView text = new  TextView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 15, 0, 0);
        params.gravity = Gravity.CENTER;
        text.setLayoutParams(params1);
        text.setTextSize(20);
        text.setGravity(50);
        Typeface typeface = getResources().getFont(R.font.kitvxvf);
        text.setTypeface(typefacetitel);
        text.setText("      1.คูชั่น : ลงคูชั่นลงทั่วบริเวณใบหน้า");
        linearLayout.addView(text);

        TextView text1 = new  TextView(this);
        LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params1.setMargins(0, 15, 0, 0);
        params1.gravity = Gravity.CENTER;
        text1.setLayoutParams(params1);
        text1.setTextSize(20);
        text1.setGravity(50);
        Typeface typetwo = getResources().getFont(R.font.kitvxvf);
        text1.setTypeface(typefacetitel);
        text1.setText("      2.คิ้ว : เขียนคิ้วสไตล์ของท่าน ให้ดูสาวเกาหลี");
        linearLayout.addView(text1);

        TextView text2 = new  TextView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams2.setMargins(0, 15, 0, 0);
        layoutParams2.gravity = Gravity.CENTER;
        text2.setLayoutParams(params1);
        text2.setTextSize(20);
        text2.setGravity(50);
        Typeface typethree = getResources().getFont(R.font.kitvxvf);
        text2.setTypeface(typefacetitel);
        text2.setText("      3.ตา : เน้นโทนธรรมชาติแบบสีน้ำตาล");
        linearLayout.addView(text2);

        TextView text3 = new  TextView(this);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams3.setMargins(0, 15, 0, 0);
        layoutParams3.gravity = Gravity.CENTER;
        text3.setLayoutParams(params1);
        text3.setTextSize(20);
        text3.setGravity(50);
        Typeface typetfour = getResources().getFont(R.font.kitvxvf);
        text3.setTypeface(typefacetitel);
        text3.setText("      4.อายไลน์เนอร์ : เขียนอายไลน์เนอร์ ให้หางตกลงมา");
        linearLayout.addView(text3);

        TextView text4 = new  TextView(this);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams4.setMargins(0, 15, 0, 0);
        layoutParams4.gravity = Gravity.CENTER;
        text4.setLayoutParams(params1);
        text4.setTextSize(20);
        text4.setGravity(50);
        Typeface typetfive = getResources().getFont(R.font.kitvxvf);
        text4.setTypeface(typefacetitel);
        text4.setText("      5.ปาก : สาวเกาหลีนิยมทาลิปสติกแบบเบลอ นัวๆตรงขอบปาก");
        linearLayout.addView(text4);

        TextView text5 = new  TextView(this);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams5.setMargins(0, 15, 0, 0);
        layoutParams5.gravity = Gravity.CENTER;
        text5.setLayoutParams(params1);
        text5.setTextSize(20);
        text5.setGravity(50);
        Typeface typetsix = getResources().getFont(R.font.kitvxvf);
        text5.setTypeface(typefacetitel);
        text5.setText("      6.แก้ม : เน้นสีที่เป็นธรรมชาติ จะได้ไม่ดูโดดจนเกินไป\"");
        linearLayout.addView(text5);



        Button button = (Button)findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(menuone.this, menu.class);
                startActivity(intent3);
            }
        } );

        Button button7 = (Button)findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent4 = new Intent(menuone.this, cosmeone.class);
                startActivity(intent4);
                finish();
            }
        });


        LinearLayout linearLayout1 = findViewById(R.id.rootContainer);
        if (linearLayout1 != null) {
            linearLayout1.addView(scrollView);
        }

    }
}
