package com.example.makeup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button button4 = (Button)findViewById(R.id.look1);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(menu.this, menuone.class);
                startActivity(intent1);
            }
        });

        Button look2 = (Button)findViewById(R.id.look2);
        look2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(menu.this, menutwo.class);
                startActivity(intent2);
            }
        });

        Button look3 = (Button)findViewById(R.id.look3);
        look3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(menu.this, menuthree.class);
                startActivity(intent3);
            }
        });

        Button look4 = (Button)findViewById(R.id.look4);
        look4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(menu.this, menufour.class);
                startActivity(intent3);
            }
        });


    }
}
